Welcome to the Yashal wiki!
