Welcome to the Yashal Aziz bio data 
yashal is from islamabad 
he is a brillant guy who has made his own website on 22 may 2018 
he is just 18 
for more informations about yashal 
follow him on facebook 🔘
Instagram 
yaashalaziz@gmail.com
His website is following 
Yashaldotblog.wordpress.com